#ifndef DOSTAWCA_H
#define DOSTAWCA_H

void proces_dostawcy(int id);

#endif