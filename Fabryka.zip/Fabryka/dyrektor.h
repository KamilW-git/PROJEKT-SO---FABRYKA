#ifndef DYREKTOR_H
#define DYREKTOR_H

void proces_dyrektora();

#endif