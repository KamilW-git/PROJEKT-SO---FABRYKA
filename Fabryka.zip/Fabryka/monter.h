#ifndef MONTER_H
#define MONTER_H

void proces_montera(int id);

#endif